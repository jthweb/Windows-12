Color Thief
-----------

A module for grabbing the color palette from an image.

Links
`````

* `github <https://github.com/fengsp/color-thief-py>`_
* `development version
  <http://github.com/fengsp/color-thief-py/zipball/master#egg=color-thief-py-dev>`_



